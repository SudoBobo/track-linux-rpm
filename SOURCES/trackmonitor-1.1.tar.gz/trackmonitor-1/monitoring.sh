#!/usr/bin/env bash
logger -s 'OK' 2>> /var/log/trackmonitor/monitoring.log
