#!/usr/bin/env bash
logger -p local1.info `df -sh /`
