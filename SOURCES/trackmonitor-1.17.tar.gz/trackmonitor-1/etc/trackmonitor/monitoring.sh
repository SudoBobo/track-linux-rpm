#!/bin/sh
logger -p local1.info `df -h /`
