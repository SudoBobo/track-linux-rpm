#!/usr/bin/env bash
echo 'OK' >> /var/log/trackmonitor/monitoring.log
exit 0
